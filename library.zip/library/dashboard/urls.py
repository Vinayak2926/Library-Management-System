from django.urls import path
from .import views

urlpatterns = [


    # Authentication operations urls 
    path('admin-login/',views.adminLogin, name='adminLogin'),
    path('admin-register/',views.adminRegister, name='adminRegister'),
    path('admin-logout/',views.adminLogout, name='adminLogout'),
    
    # Books CRUD Operations urls
    path('',views.home, name='home'),
    path('add-new-book/',views.addNewBook, name='addNewBook'),
    path('book-details/<int:id>',views.bookDetails, name='bookDetails'),
    path('update-book-details/<int:id>/',views.updateBookDetails, name='updateBookDetails'),
    path('delete-book/<int:id>',views.deleteBook, name='deleteBook'),
    
]   