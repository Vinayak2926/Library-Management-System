from django.db import models
from django.contrib.auth.models import User, auth


class Book(models.Model):
    id = models.AutoField(primary_key=True)
    addedBy = models.ForeignKey(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=200, default= "")
    authorName = models.CharField(max_length=200, default= "")
    addedDate = models.DateTimeField(null = True) 
    
    category = models.CharField(max_length=100, default= "")
    description  = models.TextField(default= "")
    noOfPages = models.CharField(max_length=100, default= "")  
    language = models.CharField(max_length=100, default= "")  
    publisher = models.CharField(max_length=100, default= "")  
    publishingDate = models.DateField(null =True)
    dimention = models.CharField(max_length=100, default= "")  
    originCountry = models.CharField(max_length=100, default= "")  
    
    
    photo = models.ImageField(upload_to="dashboard/images/books",default="")
    status = models.CharField(max_length=200, default="available")
    
    def ___str___(self): 
            return self.name
