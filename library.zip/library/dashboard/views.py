from django.shortcuts import render,redirect
from django.contrib.auth.models import User, auth
from django.contrib.auth import authenticate, login,logout
from dashboard.models import Book
from django.contrib import messages
import datetime
from django.contrib.auth.decorators import login_required

# User Authentication Views
def adminLogin(request):
    if request.method == 'POST':
        # get login details 
        username = request.POST['email'] 
        password = request.POST['password']

        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)
            messages.success(request,'Login Successfull')
            return redirect('/')
        else:
            messages.success(request,'Invalid Credentials')
            return redirect('/admin-login')
    return render(request, 'dashboard/login.html')

def adminRegister(request):
    if request.method == 'POST':
        # Get Registser details 
        name = request.POST['name']
        email = request.POST['email']
        password = request.POST['password']
        
        # check email aready exists
        if User.objects.filter(email = email).exists():
            messages.success(request, 'Email address already exists with us.')
            return redirect('/admin-register/')
        

        # create new user account 
        newUser = User.objects.create_user(username=email, email=email, password=password, first_name = name)
        newUser.save()
        print('\nNew User Account Created : ')
        user = User.objects.get(email = email)

        # Make User Login 
        userLogin = auth.authenticate(username=email, password=password)
        if userLogin is not None:
            auth.login(request, userLogin)
            messages.success(request,'New user account created.')
            return redirect('/')
        else:
            messages.success(request,'Something went wrong')
            return redirect('/admin-register')

    return render(request,'dashboard/register.html')

def adminLogout(request):
    logout(request)
    messages.success(request,'Logout successfull.')
    return redirect('/admin-login')


# Admin CRUD Operations views
@login_required(login_url = '/admin-login')
def home(request):
    books = Book.objects.filter(addedBy_id = request.user.id).order_by('-id')

    params = {'books':books}
    return render(request, 'dashboard/index.html', params) 

@login_required(login_url = '/admin-login')
def bookDetails(request, id):
    book = Book.objects.get(id = id )

    params = {'book':book }
    return render(request, 'dashboard/book-details.html', params)

@login_required(login_url = '/admin-login')
def addNewBook(request):
    if request.method == 'POST':
        # get html data from post
          
        addedBy = User.objects.get(id = request.user.id)
        name = request.POST['name']
        authorName = request.POST['authorName']
        addedDate = datetime.datetime.now()
        category = request.POST['category']
        description = request.POST['description']
        noOfPages = request.POST['noOfPages']
        language = request.POST['language']
        publisher = request.POST['publisher']
        publishingDate = request.POST['publishingDate']
        dimention = request.POST['dimention']
        originCountry = request.POST['originCountry']
        photo = request.FILES['photo']

        book = Book(addedBy = addedBy, name = name, authorName= authorName, addedDate = addedDate, category= category, description = description, noOfPages = noOfPages, language = language, publisher = publisher, publishingDate = publishingDate, dimention = dimention, originCountry = originCountry, photo = photo)
        book.save()

        messages.success(request, 'New Added successfully')
        return redirect('/')
    return render(request, 'dashboard/add-new-book.html')

@login_required(login_url = '/admin-login')
def updateBookDetails(request, id):
    if request.method == 'POST':
        book =Book.objects.get(id = id )

        book.name = request.POST['name']
        book.authorName = request.POST['authorName']
        book.category = request.POST['category']
        book.description = request.POST['description']
        book.noOfPages = request.POST['noOfPages']
        book.language = request.POST['language']
        book.publisher = request.POST['publisher']
        book.publishingDate = request.POST['publishingDate']
        book.dimention = request.POST['dimention']
        book.originCountry = request.POST['originCountry']
        book.photo = request.FILES['photo']

        book.save()
        messages.success(request, 'Book Details Updated')
        return redirect('/book-details/'+str(id))
    
    return redirect('/book-details/'+str(id))

@login_required(login_url = '/admin-login')
def deleteBook(request, id):
    book = Book.objects.get(id = id )
    book.delete()

    messages.success(request, 'Book deleted')
    return redirect('/')